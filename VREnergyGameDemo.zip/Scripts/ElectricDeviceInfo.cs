﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ElectricDeviceInfo : MonoBehaviour {
    //this class keeps information about electric device and controls whether it works or not
	public float energyConsumption;
	public bool isWorking;
    
    ///<summary>
    ///Enable device is a method that changes devices working state bool to opposite
    ///</summary>
    public void EnableDevice()
    {
        isWorking = !isWorking;
    }
}
