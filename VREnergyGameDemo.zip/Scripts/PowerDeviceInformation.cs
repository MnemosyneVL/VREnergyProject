﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerDeviceInformation : MonoBehaviour
{
    //This class contains information about the power device and it's characteristics
    public float powerAmount = 0f;
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("Power Generator Here!");
    }
}
