﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Snapping : MonoBehaviour {
    //This class stores logic and settings for object snappig system, that was made for easier VR interactions w objects
	private SphereCollider snappingZone;
	public bool isGrabbed = false;
	public bool isWorking = false;
	public float energyConsumptionAmount;
	FixedJoint snappingJoint;
	private GameObject lightHolder;
	
	// Use this for initialization
	void Start () 
	{
		snappingZone = GetComponent<SphereCollider>();
		lightHolder = gameObject.transform.Find("Light").gameObject;
		lightHolder.GetComponent<Light>().enabled = false;
		energyConsumptionAmount = 0f;
	}
	
	//Update checks if light component needs to be on or not
	void Update ()
	{
            if (isWorking)
            {
                lightHolder.GetComponent<Light>().enabled = true;
            }
            else
            {
                lightHolder.GetComponent<Light>().enabled = false;
            }		
	}
    /// <summary>
    /// On trigger enter checks if object is in range of this socket. 
    /// If so then object is frozen with a joint and isWorking bool is set to true. 
    /// </summary>
	private void OnTriggerEnter(Collider target)
	{
            if (target.tag == gameObject.tag && !isGrabbed)
            {
                if(target.GetComponent<ElectricDeviceInfo>() != null)
                {
                    energyConsumptionAmount = target.GetComponent<ElectricDeviceInfo>().energyConsumption;
                    target.GetComponent<ElectricDeviceInfo>().isWorking = true;
                }
                target.transform.position = transform.position;
                target.transform.rotation = transform.rotation;
                snappingJoint = gameObject.AddComponent<FixedJoint>();
                snappingJoint.connectedBody = target.gameObject.GetComponent<Rigidbody>();
                isWorking = true;
            }
            else if (isGrabbed)
            {
                Destroy(gameObject.GetComponent<FixedJoint>());
                isWorking = false;
                energyConsumptionAmount = 0f;
                if(target.GetComponent<ElectricDeviceInfo>() != null)
                {
                   target.GetComponent<ElectricDeviceInfo>().isWorking = false; 
                }
                

            }		
	} 
}
