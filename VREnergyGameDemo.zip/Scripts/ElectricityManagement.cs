﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ElectricityManagement : MonoBehaviour {

    /* This class contains logic to track all electricity consumers on
    the level and show the left amount of energy on an in game screen*/
	[SerializeField]
	GameObject[] consumers;
	public float powerAmountVariable;
	public float powerAmountLeft;
	[SerializeField]
	Text textHolder;
	[SerializeField]
	GameObject powerSource;
	public float consumptionVariable = 0f;
    /*An array with all energy consumers is filled in here*/
	void Start () {
		consumers = GameObject.FindGameObjectsWithTag("ElectricityConsumer");
		for (int j = 0; j < consumers.Length; j++)
		{
			consumers[j] = consumers[j].transform.parent.gameObject;
		}
		powerAmountVariable = powerSource.GetComponent<PowerDeviceInformation>().powerAmount;
	}
	
	/* This code scans through all energy consumers and
    substracts their energy consumption amount from available power amount*/
	void Update () {

            for (int i = 0; i < consumers.Length; i++)
            {
				if (consumers[i].GetComponent<ElectricDeviceInfo>() != null)
				{
					if (consumers[i].GetComponent<ElectricDeviceInfo>().isWorking == true)
					{
						consumptionVariable+=consumers[i].GetComponent<ElectricDeviceInfo>().energyConsumption;
					}
				}

            }
			powerAmountLeft = powerAmountVariable - consumptionVariable;
            textHolder.text = powerAmountLeft.ToString();
            consumptionVariable = 0f;
	}
}
