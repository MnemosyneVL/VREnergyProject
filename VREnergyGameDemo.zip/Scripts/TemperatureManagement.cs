﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TemperatureManagement : MonoBehaviour
{
    [SerializeField]
	GameObject[] heaters;

    [SerializeField]
    Text textHolder;
    public float temperaturePowerVariable =0f;
    public float currentTemperature = 0f;
    private float temperatureForDisplay;
    public float minTemperature = 0f;
    private float t;
    /* All heating devices are added to an array here*/
    void Start()
    {
        heaters = GameObject.FindGameObjectsWithTag("HeaterObject");
		for (int j = 0; j < heaters.Length; j++)
		{
			heaters[j] = heaters[j].transform.parent.gameObject;
		}
    }

    /* This update method scans through all heaters in the heaters array 
    and checks if they are currenly working and slowly adds or substracts temperature according to 
    amoung and of working heaters */
    void Update()
    {
        for (int i = 0; i < heaters.Length; i++)
            {
				if (heaters[i].GetComponent<HeaterDeviceInformation>() != null)
				{
					if (heaters[i].GetComponent<ElectricDeviceInfo>().isWorking == true)
					{
						temperaturePowerVariable+=heaters[i].GetComponent<HeaterDeviceInformation>().heaterPower;
					}
				}

            }

        if (currentTemperature <= temperaturePowerVariable)
        {
            currentTemperature += 0.1f * Time.deltaTime;
        }
        else
        {
            currentTemperature -= 0.1f * Time.deltaTime;
        }
        temperatureForDisplay = Mathf.Round(currentTemperature*10f)/10f;
        textHolder.text = temperatureForDisplay.ToString();
        temperaturePowerVariable = 0f;
    }
    /* OBSOLETE CODE
    IEnumerator DoVariableUpdate(float time)
    {
        for (; ; )
        {
            currentTemperature = Mathf.Lerp(currentTemperature, temperaturePowerVariable, 0.5f);
            yield return new WaitForSeconds(time);
      
        }

        
        
    }*/
}
