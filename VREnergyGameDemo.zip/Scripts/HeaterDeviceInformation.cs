﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeaterDeviceInformation : MonoBehaviour
{
    //This class stores information about heating device and all it's characteristics
    public float heaterPower = 0f;
    private bool electricComponent;
    // Start is called before the first frame update
    void Start()
    {
        electricComponent = GetComponent<ElectricDeviceInfo>().isWorking;
        Debug.Log("Heater Device is Here!");
    }
}
